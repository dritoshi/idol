library(testthat)
library(idol)

test_package("idol")